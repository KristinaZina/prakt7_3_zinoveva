fun main(){
    println("введите сторону треугольна A ")
    val A = readLine()!!.toInt()
    println("введите сторону треугольна B ")
    val B = readLine()!!.toInt()
    println("введите сторону треугольна C ")
    val C = readLine()!!.toInt()
    when {
        A + B > C && A + C > B && B + C > A ->
            {
            val p = (A + B + C) / 2  // расчет полупериметра
            val S = (p*(p-A)*(p-B)*(p-C))//расчет площади
            val h = 2*S/A//высота
            println("Высота, опущенная на сторону A: $h")
        }
        else -> {
            println("несуществующий треугольник")
        }
    }
}