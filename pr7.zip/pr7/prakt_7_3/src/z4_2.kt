fun main() {
    println("введите значение x:")
    val x = readLine()!!.toDouble()
    println("введите значение y:")
    val y = readLine()!!.toDouble()
    println("введите значение z:")
    val z = readLine()!!.toDouble()
    val U =
        when
        {
        y < 0 -> minOf(z, maxOf(x, y)) //функция при  y < 0
        else -> maxOf(z, minOf(x, y)) //функция при y >= 0
    }
    println("U = $U")
}