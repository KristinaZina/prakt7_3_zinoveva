fun main(){
    println("введите четырехзначное число")
    val num= readLine()!!.toInt()
    if (num<1000||num>9999)
    {
        println("введите корректное четырехзначное число")
        return
    }
    var count=0 // счетчик для накопления суммы
    var numb=num
    for (i in 1..4)//перебор чисел с первого до последнего
    {
        val posl=numb%10// нахождение последней цифры
        count+=posl // сумма цифр
        numb=numb/10// удаление последней цифры
        when(i)
        {
            4-> println("первая цифра $posl")
            3-> println("вторая цифра $posl")
            2-> println("третья цифра $posl")
            1-> println("четвертая цифра $posl")
        }
    }
    println("сумма цифр = $count")
}