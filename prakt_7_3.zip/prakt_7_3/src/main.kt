import kotlin.math.sqrt

fun main(){
    var D =0
    println("введите a")
    val a = readLine()!!.toInt()
    println("введите b")
    val b = readLine()!!.toInt()
    println("введите c")
    val c = readLine()!!.toInt()
    println("введите x")
    val x = readLine()!!.toInt()
    when{ //проверка
        a==0||b==0||c==0->{
            println("не верный ввод")
            return
        }
        else->{
            D=b*b-4*a*c//формула дискрименанта
            if (D>0)
            {
                println("$a*$x^4$b*$x^2$c=0")//вывод вырвжения
                val x1=-b+ sqrt(D.toDouble())/2//корни уравнения
                val x2=b+ sqrt(D.toDouble())/2
                println("корни уравнения: x1=$x1 x2=$x2 ")
            }
            else
            {
                println("нет корней")
            }
        }
    }


}